import React from 'react';
import type { Metadata } from 'next';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import BlogHero from './components/BlogHero';
import FeaturedArticle from './components/FeaturedArticle';
import BlogGrid from './components/BlogGrid';
import BlogSidebar from './components/BlogSidebar';

export const metadata: Metadata = {
  title: 'Blog — Screen Size & Resolution Guides | ScreenSizer',
  description: 'In-depth articles on screen resolution, viewport sizes, device pixel ratio, responsive design, and web performance. Expert guides for developers and designers.',
  openGraph: {
    title: 'ScreenSizer Blog — Screen Size & Resolution Guides',
    description: 'Expert articles on screen resolution, DPR, responsive design, and viewport sizes.',
    url: 'https://screensizer.io/blog',
  },
  alternates: { canonical: 'https://screensizer.io/blog' },
};

export default function BlogPage() {
  return (
    <>
      <Header />
      <main>
        <BlogHero />
        <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-10 py-12 lg:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-3 xl:grid-cols-4 gap-10">
            <div className="lg:col-span-2 xl:col-span-3">
              <FeaturedArticle />
              <BlogGrid />
            </div>
            <div className="lg:col-span-1">
              <BlogSidebar />
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}