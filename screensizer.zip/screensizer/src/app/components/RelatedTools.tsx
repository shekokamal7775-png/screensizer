import React from 'react';
import Link from 'next/link';
import { Ruler, Monitor, Smartphone, Zap, Eye, Code2, ArrowUpRight } from 'lucide-react';

const tools = [
  {
    key: 'viewport-tester',
    icon: <Ruler size={20} className="text-primary" />,
    name: 'Viewport Size Tester',
    desc: 'Test how your site looks at specific viewport widths. Enter any dimension to simulate.',
    href: '/#tool',
    badge: 'Free',
    badgeColor: 'bg-success/10 text-success',
  },
  {
    key: 'dpr-checker',
    icon: <Eye size={20} className="text-accent" />,
    name: 'DPR Checker',
    desc: 'Check your Device Pixel Ratio and understand if your device is Retina or HiDPI.',
    href: '/#tool',
    badge: 'Free',
    badgeColor: 'bg-success/10 text-success',
  },
  {
    key: 'responsive-checker',
    icon: <Smartphone size={20} className="text-warning" />,
    name: 'Responsive Design Checker',
    desc: 'See how your website renders at common mobile, tablet, and desktop breakpoints.',
    href: '/#tool',
    badge: 'Free',
    badgeColor: 'bg-success/10 text-success',
  },
  {
    key: 'monitor-size',
    icon: <Monitor size={20} className="text-primary" />,
    name: 'Monitor Size Detector',
    desc: 'Detect your physical monitor diagonal size based on resolution and DPR.',
    href: '/#tool',
    badge: 'Free',
    badgeColor: 'bg-success/10 text-success',
  },
  {
    key: 'css-breakpoint',
    icon: <Code2 size={20} className="text-accent" />,
    name: 'CSS Breakpoint Tester',
    desc: 'See which Tailwind CSS, Bootstrap, or custom media query breakpoint is currently active.',
    href: '/#tool',
    badge: 'Free',
    badgeColor: 'bg-success/10 text-success',
  },
  {
    key: 'performance',
    icon: <Zap size={20} className="text-warning" />,
    name: 'Page Speed Analyzer',
    desc: 'Analyze Core Web Vitals and loading performance for any URL.',
    href: '/#tool',
    badge: 'Soon',
    badgeColor: 'bg-warning/15 text-warning',
  },
];

export default function RelatedTools() {
  return (
    <section className="py-14 lg:py-20 bg-background" aria-labelledby="tools-heading">
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-10">
        <div className="text-center mb-10">
          <h2 id="tools-heading" className="text-2xl sm:text-3xl font-700 text-foreground mb-3">
            Related Free Tools
          </h2>
          <p className="text-muted-foreground text-sm sm:text-base max-w-xl mx-auto">
            More free web development and design tools to help you build better, faster, and more responsive websites.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-3 gap-5">
          {tools?.map((tool) => (
            <Link
              key={`tool-${tool?.key}`}
              href={tool?.href}
              className="group bg-card border border-border rounded-xl p-5 card-shadow hover:card-shadow-hover hover:-translate-y-0.5 transition-all duration-200 flex flex-col"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="p-2.5 bg-secondary rounded-xl">{tool?.icon}</div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-600 px-2 py-0.5 rounded-full ${tool?.badgeColor}`}>
                    {tool?.badge}
                  </span>
                  <ArrowUpRight size={14} className="text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
              </div>
              <h3 className="text-sm font-700 text-foreground mb-2">{tool?.name}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed flex-1">{tool?.desc}</p>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}