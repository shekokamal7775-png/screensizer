import React from 'react';
import Link from 'next/link';
import { Monitor, ArrowRight, BookOpen } from 'lucide-react';

export default function CTASection() {
  return (
    <section className="py-14 lg:py-20 bg-background" aria-labelledby="cta-heading">
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-10">
        <div className="bg-card border border-border rounded-2xl card-shadow overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            {/* Primary CTA */}
            <div className="p-8 sm:p-10 lg:border-r border-border">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/10 rounded-2xl mb-5">
                <Monitor size={22} className="text-primary" />
              </div>
              <h2 id="cta-heading" className="text-xl sm:text-2xl font-700 text-foreground mb-3">
                Check Your Screen Size Now
              </h2>
              <p className="text-muted-foreground text-sm leading-relaxed mb-6">
                Scroll back to the top to see your screen dimensions, viewport size, DPR, device type, and browser information — all detected automatically and updated live as you resize.
              </p>
              <a
                href="/#tool"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground text-sm font-600 rounded-xl hover:opacity-90 active:scale-95 transition-all duration-150"
              >
                <Monitor size={15} />
                View My Screen Size
                <ArrowRight size={14} />
              </a>
            </div>

            {/* Blog CTA */}
            <div className="p-8 sm:p-10 bg-secondary/30">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-accent/10 rounded-2xl mb-5">
                <BookOpen size={22} className="text-accent" />
              </div>
              <h3 className="text-xl sm:text-2xl font-700 text-foreground mb-3">
                Learn About Screen Resolutions
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed mb-6">
                Read our in-depth SEO guide on screen sizes, resolutions, and what they mean for web design, performance, and user experience in 2025.
              </p>
              <Link
                href="/blog"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-accent text-accent-foreground text-sm font-600 rounded-xl hover:opacity-90 active:scale-95 transition-all duration-150"
              >
                <BookOpen size={15} />
                Read the Guide
                <ArrowRight size={14} />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}