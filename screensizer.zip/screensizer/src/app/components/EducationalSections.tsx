import React from 'react';
import Link from 'next/link';
import { BookOpen, CheckCircle, ArrowRight } from 'lucide-react';

export default function EducationalSections() {
  return (
    <section className="py-14 lg:py-20 bg-background" aria-labelledby="edu-heading">
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-10">
        {/* What is screen resolution */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center mb-20">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-600 text-primary bg-primary/10 px-3 py-1.5 rounded-full mb-4">
              <BookOpen size={12} />
              Learn
            </div>
            <h2 id="edu-heading" className="text-2xl sm:text-3xl font-700 text-foreground mb-4 leading-tight">
              What Is Screen Resolution?
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-5">
              Screen resolution refers to the total number of pixels displayed on a screen, expressed as width × height (e.g., 1920×1080). It determines how much content can fit on your display and how sharp images appear. A higher resolution means more pixels — and typically a sharper, more detailed picture.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-6">
              It is important to distinguish between <strong className="text-foreground">physical resolution</strong> (the actual hardware pixel count) and <strong className="text-foreground">CSS resolution</strong> (the logical pixel space used by web browsers). High-DPI displays like Apple Retina screens use 2x or 3x scaling, meaning the physical pixel count is much higher than what CSS reports.
            </p>
            <ul className="space-y-2.5 mb-6">
              {[
                'Physical pixels = CSS pixels × Device Pixel Ratio',
                'Full HD (1920×1080) is the most common desktop resolution globally',
                'Mobile screens typically report 360–414px in CSS width',
                'Retina displays have DPR of 2.0 or higher',
              ]?.map((item) => (
                <li key={`edu1-${item?.slice(0, 20)}`} className="flex items-start gap-2.5 text-sm text-secondary-foreground">
                  <CheckCircle size={15} className="text-success flex-shrink-0 mt-0.5" />
                  {item}
                </li>
              ))}
            </ul>
            <Link
              href="/blog"
              className="inline-flex items-center gap-1.5 text-sm font-600 text-primary hover:underline"
            >
              Read the full guide <ArrowRight size={14} />
            </Link>
          </div>
          <div className="bg-secondary rounded-2xl p-6 border border-border">
            <h3 className="text-sm font-700 text-foreground uppercase tracking-wide mb-4">Resolution Reference Table</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 text-xs font-600 text-muted-foreground">Name</th>
                    <th className="text-left py-2 text-xs font-600 text-muted-foreground">Resolution</th>
                    <th className="text-left py-2 text-xs font-600 text-muted-foreground">Device</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    ['HD', '1280 × 720', 'Laptop/TV'],
                    ['Full HD', '1920 × 1080', 'Desktop/TV'],
                    ['QHD / 2K', '2560 × 1440', 'Monitor'],
                    ['4K UHD', '3840 × 2160', 'TV/Monitor'],
                    ['iPhone 14', '390 × 844', 'Mobile'],
                    ['iPad Air', '820 × 1180', 'Tablet'],
                  ]?.map(([name, res, device]) => (
                    <tr key={`res-table-${name}`} className="border-b border-border/50 hover:bg-card transition-colors">
                      <td className="py-2.5 font-600 text-foreground text-xs">{name}</td>
                      <td className="py-2.5 font-mono text-xs text-primary">{res}</td>
                      <td className="py-2.5 text-xs text-muted-foreground">{device}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* How to check screen size */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center mb-20">
          <div className="order-2 lg:order-1">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                { title: 'Using ScreenSizer', desc: 'Visit screensizer.io — your screen dimensions appear instantly at the top of the page, no interaction needed.', num: '01' },
                { title: 'System Settings', desc: 'On Windows: Settings → Display. On macOS: System Preferences → Displays. On Android: Settings → Display.', num: '02' },
                { title: 'Browser DevTools', desc: 'Press F12, click the device toolbar icon, and select a device preset or enter custom dimensions.', num: '03' },
                { title: 'CSS Media Query', desc: 'Use @media (max-width: 768px) to target specific breakpoints in your stylesheet.', num: '04' },
              ]?.map((step) => (
                <div key={`step-${step?.num}`} className="bg-card border border-border rounded-xl p-4 card-shadow">
                  <span className="metric-value text-3xl font-800 text-primary/20 block mb-2">{step?.num}</span>
                  <h4 className="text-sm font-700 text-foreground mb-1.5">{step?.title}</h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">{step?.desc}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="order-1 lg:order-2">
            <div className="inline-flex items-center gap-1.5 text-xs font-600 text-accent bg-accent/10 px-3 py-1.5 rounded-full mb-4">
              <BookOpen size={12} />
              How-To
            </div>
            <h2 className="text-2xl sm:text-3xl font-700 text-foreground mb-4 leading-tight">
              How to Check Your Screen Size
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-5">
              There are several ways to find your screen resolution — from using a dedicated tool like ScreenSizer to digging into your OS settings or browser developer tools. Each method provides slightly different data depending on your use case.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              For web developers, the most relevant measurements are <strong className="text-foreground">viewport width/height</strong> (what CSS sees) and <strong className="text-foreground">Device Pixel Ratio</strong> (for serving the right image assets). For hardware comparisons, physical screen resolution is what matters.
            </p>
          </div>
        </div>

        {/* Why it matters */}
        <div className="bg-gradient-primary rounded-2xl p-8 sm:p-10 text-white">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-2xl sm:text-3xl font-700 mb-4 leading-tight">
                Why Screen Resolution Matters
              </h2>
              <p className="text-white/80 leading-relaxed mb-5">
                Screen resolution directly impacts user experience, content legibility, image sharpness, and how responsive websites render. For designers, it determines canvas size. For developers, it determines breakpoints and asset delivery. For end users, it affects how much they can see at once.
              </p>
              <Link
                href="/blog"
                className="inline-flex items-center gap-1.5 bg-white text-primary text-sm font-700 px-5 py-2.5 rounded-xl hover:bg-white/90 active:scale-95 transition-all duration-150"
              >
                Read Full Guide <ArrowRight size={14} />
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {[
                { stat: '68%', label: 'of web traffic is mobile', icon: '📱' },
                { stat: '1920px', label: 'most common desktop width', icon: '🖥️' },
                { stat: '2.0x', label: 'average DPR on modern phones', icon: '🔍' },
                { stat: '360px', label: 'most common mobile viewport', icon: '📐' },
              ]?.map((s) => (
                <div key={`stat-${s?.stat}`} className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
                  <div className="text-xl mb-1">{s?.icon}</div>
                  <div className="metric-value text-xl font-800 text-white mb-1">{s?.stat}</div>
                  <div className="text-xs text-white/70 leading-tight">{s?.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}