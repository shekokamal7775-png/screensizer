'use client';
import React, { useState, useEffect, useCallback } from 'react';
import { Copy, Check, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

interface ScreenData {
  screenWidth: number;
  screenHeight: number;
  viewportWidth: number;
  viewportHeight: number;
  dpr: number;
  windowWidth: number;
  windowHeight: number;
  orientation: string;
  colorDepth: number;
}

function detect(): ScreenData {
  return {
    screenWidth: window.screen.width,
    screenHeight: window.screen.height,
    viewportWidth: document.documentElement.clientWidth,
    viewportHeight: document.documentElement.clientHeight,
    dpr: window.devicePixelRatio,
    windowWidth: window.innerWidth,
    windowHeight: window.innerHeight,
    orientation: window.innerWidth > window.innerHeight ? 'Landscape' : 'Portrait',
    colorDepth: window.screen.colorDepth,
  };
}

const defaultData: ScreenData = {
  screenWidth: 0,
  screenHeight: 0,
  viewportWidth: 0,
  viewportHeight: 0,
  dpr: 1,
  windowWidth: 0,
  windowHeight: 0,
  orientation: 'Landscape',
  colorDepth: 24,
};

export default function LiveMetricDisplay() {
  const [data, setData] = useState<ScreenData>(defaultData);
  const [ready, setReady] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [pulse, setPulse] = useState(false);

  const refresh = useCallback(() => {
    setData(detect());
    setPulse(true);
    setTimeout(() => setPulse(false), 600);
  }, []);

  useEffect(() => {
    setData(detect());
    setReady(true);

    const onResize = () => {
      setData(detect());
      setPulse(true);
      setTimeout(() => setPulse(false), 600);
    };

    window.addEventListener('resize', onResize, { passive: true });
    return () => window.removeEventListener('resize', onResize);
  }, []);

  const copyValue = (label: string, value: string) => {
    navigator.clipboard.writeText(value).then(() => {
      setCopied(label);
      toast.success(`Copied: ${value}`);
      setTimeout(() => setCopied(null), 2000);
    });
  };

  const primaryMetrics = [
    { label: 'Screen Width', value: ready ? `${data.screenWidth}px` : '—', key: 'sw', desc: 'Physical screen width in CSS pixels' },
    { label: 'Screen Height', value: ready ? `${data.screenHeight}px` : '—', key: 'sh', desc: 'Physical screen height in CSS pixels' },
    { label: 'Viewport Width', value: ready ? `${data.viewportWidth}px` : '—', key: 'vw', desc: 'Visible browser viewport width' },
    { label: 'Viewport Height', value: ready ? `${data.viewportHeight}px` : '—', key: 'vh', desc: 'Visible browser viewport height' },
  ];

  return (
    <div className={`max-w-4xl mx-auto transition-all duration-300 ${pulse ? 'animate-pulse-once' : ''}`}>
      {/* Main hero metric card */}
      <div className="bg-card border border-border rounded-2xl card-shadow p-6 sm:p-8 mb-5 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-2xl" aria-hidden="true">
          <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full bg-primary/5" />
          <div className="absolute -bottom-8 -left-8 w-36 h-36 rounded-full bg-accent/5" />
        </div>

        <div className="relative">
          <div className="flex items-center justify-between mb-6">
            <div>
              <p className="text-xs font-600 text-muted-foreground uppercase tracking-widest mb-1">Your Screen Size</p>
              <div className="flex items-baseline gap-2">
                <span className="metric-value text-4xl sm:text-5xl font-800 text-foreground">
                  {ready ? data.screenWidth : '—'}
                </span>
                <span className="text-xl font-600 text-muted-foreground">×</span>
                <span className="metric-value text-4xl sm:text-5xl font-800 text-foreground">
                  {ready ? data.screenHeight : '—'}
                </span>
                <span className="text-xl font-500 text-muted-foreground">px</span>
              </div>
            </div>
            <div className="flex flex-col items-end gap-2">
              <button
                onClick={refresh}
                title="Refresh measurements"
                className="p-2 rounded-lg bg-secondary text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all duration-150 active:scale-95"
              >
                <RefreshCw size={16} />
              </button>
              <button
                onClick={() => copyValue('screen-size', ready ? `${data.screenWidth}x${data.screenHeight}` : '')}
                title="Copy screen size"
                className="p-2 rounded-lg bg-secondary text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all duration-150 active:scale-95"
              >
                {copied === 'screen-size' ? <Check size={16} className="text-success" /> : <Copy size={16} />}
              </button>
            </div>
          </div>

          {/* 4 primary metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {primaryMetrics.map((m) => (
              <div
                key={`primary-${m.key}`}
                className="group bg-secondary rounded-xl p-3.5 hover:bg-primary/8 transition-all duration-150 cursor-default"
                title={m.desc}
              >
                <p className="text-xs font-500 text-muted-foreground mb-1.5">{m.label}</p>
                <div className="flex items-center justify-between">
                  <span className="metric-value text-lg font-700 text-foreground">{m.value}</span>
                  <button
                    onClick={() => copyValue(m.key, m.value)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity duration-150 p-1 rounded text-muted-foreground hover:text-primary"
                    title={`Copy ${m.label}`}
                  >
                    {copied === m.key ? <Check size={12} className="text-success" /> : <Copy size={12} />}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Secondary metrics row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Device Pixel Ratio', value: ready ? `${data.dpr}x` : '—', key: 'dpr', color: 'text-primary' },
          { label: 'Window Width', value: ready ? `${data.windowWidth}px` : '—', key: 'ww', color: 'text-accent' },
          { label: 'Window Height', value: ready ? `${data.windowHeight}px` : '—', key: 'wh', color: 'text-accent' },
          { label: 'Orientation', value: ready ? data.orientation : '—', key: 'orient', color: ready && data.orientation === 'Portrait' ? 'text-warning' : 'text-success' },
        ].map((m) => (
          <div
            key={`secondary-${m.key}`}
            className="group bg-card border border-border rounded-xl p-4 card-shadow hover:metric-card-glow transition-all duration-200"
          >
            <p className="text-xs font-500 text-muted-foreground mb-2">{m.label}</p>
            <div className="flex items-center justify-between">
              <span className={`metric-value text-xl font-700 ${m.color}`}>{m.value}</span>
              <button
                onClick={() => copyValue(m.key, m.value)}
                className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded text-muted-foreground hover:text-primary"
                title={`Copy ${m.label}`}
              >
                {copied === m.key ? <Check size={12} className="text-success" /> : <Copy size={12} />}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Live indicator */}
      <div className="flex items-center justify-center gap-2 mt-5">
        <span className="relative flex h-2.5 w-2.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75" />
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-success" />
        </span>
        <span className="text-xs text-muted-foreground">Live — resize your window to see values update in real time</span>
      </div>
    </div>
  );
}