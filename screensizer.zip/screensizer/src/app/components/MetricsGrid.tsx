'use client';
import React, { useState, useEffect } from 'react';
import {
  Monitor, Smartphone, Tablet, Globe, Code2, Cpu, Layers, Eye, RotateCcw, Palette
} from 'lucide-react';

interface DeviceMetrics {
  deviceType: string;
  os: string;
  browser: string;
  colorDepth: number;
  pixelWidth: number;
  pixelHeight: number;
  aspectRatio: string;
  touchSupport: boolean;
}

function getDeviceType(ua: string, w: number): string {
  if (/Mobi|Android|iPhone|iPod/i.test(ua)) return 'Mobile';
  if (/iPad|Tablet/i.test(ua) || (w >= 600 && w <= 1024)) return 'Tablet';
  return 'Desktop';
}

function getOS(ua: string): string {
  if (/Windows/i.test(ua)) return 'Windows';
  if (/Mac OS X/i.test(ua)) return 'macOS';
  if (/Android/i.test(ua)) return 'Android';
  if (/iPhone|iPad/i.test(ua)) return 'iOS';
  if (/Linux/i.test(ua)) return 'Linux';
  return 'Unknown OS';
}

function getBrowser(ua: string): string {
  if (/Edg\//i.test(ua)) return 'Microsoft Edge';
  if (/OPR|Opera/i.test(ua)) return 'Opera';
  if (/Chrome/i.test(ua)) return 'Google Chrome';
  if (/Safari/i.test(ua)) return 'Safari';
  if (/Firefox/i.test(ua)) return 'Mozilla Firefox';
  return 'Unknown Browser';
}

function gcd(a: number, b: number): number {
  return b === 0 ? a : gcd(b, a % b);
}

function getAspectRatio(w: number, h: number): string {
  const d = gcd(w, h);
  return `${w / d}:${h / d}`;
}

const defaultMetrics: DeviceMetrics = {
  deviceType: 'Desktop',
  os: 'Unknown OS',
  browser: 'Unknown Browser',
  colorDepth: 24,
  pixelWidth: 0,
  pixelHeight: 0,
  aspectRatio: '16:9',
  touchSupport: false,
};

export default function MetricsGrid() {
  const [metrics, setMetrics] = useState<DeviceMetrics>(defaultMetrics);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const ua = navigator.userAgent;
    const w = window.screen.width;
    const h = window.screen.height;
    const dpr = window.devicePixelRatio;
    setMetrics({
      deviceType: getDeviceType(ua, window.innerWidth),
      os: getOS(ua),
      browser: getBrowser(ua),
      colorDepth: window.screen.colorDepth,
      pixelWidth: Math.round(w * dpr),
      pixelHeight: Math.round(h * dpr),
      aspectRatio: getAspectRatio(w, h),
      touchSupport: navigator.maxTouchPoints > 0,
    });
    setReady(true);
  }, []);

  const deviceIcon = metrics.deviceType === 'Mobile'
    ? <Smartphone size={20} className="text-primary" />
    : metrics.deviceType === 'Tablet'
    ? <Tablet size={20} className="text-primary" />
    : <Monitor size={20} className="text-primary" />;

  const cards = [
    {
      key: 'device-type',
      icon: deviceIcon,
      label: 'Device Type',
      value: ready ? metrics.deviceType : '—',
      badge: ready ? (metrics.deviceType === 'Desktop' ? 'bg-primary/10 text-primary' : metrics.deviceType === 'Mobile' ? 'bg-warning/15 text-warning' : 'bg-accent/10 text-accent') : '',
      desc: 'Detected from screen width and user agent',
    },
    {
      key: 'os',
      icon: <Cpu size={20} className="text-accent" />,
      label: 'Operating System',
      value: ready ? metrics.os : '—',
      badge: '',
      desc: 'Detected from browser user agent string',
    },
    {
      key: 'browser',
      icon: <Globe size={20} className="text-success" />,
      label: 'Browser',
      value: ready ? metrics.browser : '—',
      badge: '',
      desc: 'Detected from browser user agent string',
    },
    {
      key: 'pixel-res',
      icon: <Layers size={20} className="text-primary" />,
      label: 'Physical Resolution',
      value: ready ? `${metrics.pixelWidth} × ${metrics.pixelHeight}` : '—',
      badge: '',
      desc: 'Actual physical pixels (CSS px × DPR)',
    },
    {
      key: 'aspect',
      icon: <Eye size={20} className="text-accent" />,
      label: 'Aspect Ratio',
      value: ready ? metrics.aspectRatio : '—',
      badge: '',
      desc: 'Simplified screen width to height ratio',
    },
    {
      key: 'color',
      icon: <Palette size={20} className="text-warning" />,
      label: 'Color Depth',
      value: ready ? `${metrics.colorDepth}-bit` : '—',
      badge: '',
      desc: 'Bits per pixel for color display',
    },
    {
      key: 'touch',
      icon: <Code2 size={20} className="text-primary" />,
      label: 'Touch Support',
      value: ready ? (metrics.touchSupport ? 'Supported' : 'Not Supported') : '—',
      badge: ready ? (metrics.touchSupport ? 'bg-success/10 text-success' : 'bg-muted text-muted-foreground') : '',
      desc: 'Whether the device supports touch input',
    },
    {
      key: 'css-px',
      icon: <RotateCcw size={20} className="text-accent" />,
      label: 'CSS Pixels',
      value: ready ? `${window?.screen?.width ?? 0} × ${window?.screen?.height ?? 0}` : '—',
      badge: '',
      desc: 'Logical CSS pixels reported by the browser',
    },
  ];

  return (
    <section className="py-12 lg:py-16 bg-background" aria-labelledby="metrics-grid-heading">
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-10">
        <div className="text-center mb-10">
          <h2 id="metrics-grid-heading" className="text-2xl sm:text-3xl font-700 text-foreground mb-3">
            Complete Device Information
          </h2>
          <p className="text-muted-foreground text-sm sm:text-base max-w-xl mx-auto">
            All technical details about your screen, device, and browser — detected automatically from your session.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-4 2xl:grid-cols-4 gap-4">
          {cards.map((card, i) => (
            <div
              key={card.key}
              className="bg-card border border-border rounded-xl p-5 card-shadow hover:card-shadow-hover hover:-translate-y-0.5 transition-all duration-200 animate-fade-in"
              style={{ animationDelay: `${i * 60}ms` }}
              title={card.desc}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="p-2 bg-secondary rounded-lg">{card.icon}</div>
                {card.badge && (
                  <span className={`text-xs font-600 px-2 py-0.5 rounded-full ${card.badge}`}>
                    {card.value}
                  </span>
                )}
              </div>
              <p className="text-xs font-500 text-muted-foreground uppercase tracking-wide mb-1">{card.label}</p>
              {!card.badge && (
                <p className="metric-value text-lg font-700 text-foreground">{card.value}</p>
              )}
              <p className="text-xs text-muted-foreground mt-2 leading-relaxed">{card.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}