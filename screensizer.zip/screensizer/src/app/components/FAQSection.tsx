'use client';
import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    id: 'faq-1',
    question: 'What is my screen size?',
    answer: 'Your screen size is the physical diagonal measurement of your display in inches, combined with the pixel resolution (width × height). On this tool, we detect both your screen dimensions in pixels and your device type automatically. The most common screen size for desktop monitors is 24–27 inches with 1920×1080 pixel resolution.',
  },
  {
    id: 'faq-2',
    question: 'What is the difference between screen resolution and viewport size?',
    answer: 'Screen resolution refers to the total physical pixels of your display hardware (e.g., 2560×1600 on a MacBook Pro). Viewport size is the visible area inside your browser window in CSS logical pixels, which accounts for browser chrome, toolbars, and zoom level. On a Retina display, your CSS viewport may be 1280×800 while the physical screen is 2560×1600.',
  },
  {
    id: 'faq-3',
    question: 'What is Device Pixel Ratio (DPR)?',
    answer: 'Device Pixel Ratio (DPR) is the ratio of physical pixels to CSS logical pixels on your screen. A DPR of 2.0 means 4 physical pixels (2×2) are used to render each CSS pixel, resulting in sharper text and images. Most modern smartphones have DPR of 2.0–3.0. Apple Retina displays use 2.0x on MacBooks and 3.0x on iPhones.',
  },
  {
    id: 'faq-4',
    question: 'How accurate is this screen size detector?',
    answer: 'ScreenSizer reads values directly from your browser\'s JavaScript APIs — window.screen.width, window.screen.height, window.innerWidth, window.devicePixelRatio, and navigator.userAgent. These are the most accurate values available in a browser context. No app installation is required, and values update in real time when you resize your window.',
  },
  {
    id: 'faq-5',
    question: 'What is the most common screen resolution in 2025?',
    answer: 'According to global browser statistics in 2025, the most common desktop screen resolution is 1920×1080 (Full HD), accounting for approximately 35% of all desktop sessions. For mobile devices, 390×844 (iPhone 14) and 412×915 (Google Pixel) are among the most prevalent. The trend is moving toward 2560×1440 (QHD) on premium laptops.',
  },
  {
    id: 'faq-6',
    question: 'What screen resolution should I design for?',
    answer: 'For web design, the recommended approach is mobile-first with breakpoints at 375px (small mobile), 768px (tablet), 1024px (laptop), 1280px (desktop), and 1920px (large desktop). Design your layout to be fluid between these breakpoints rather than targeting fixed resolutions. Always test at 320px minimum width for small mobile devices.',
  },
  {
    id: 'faq-7',
    question: 'How do I check screen resolution on Windows?',
    answer: 'On Windows 10/11: Right-click the Desktop → Display Settings → Scroll to Display Resolution. The current resolution is shown in a dropdown menu. You can also press Win+I to open Settings directly. For the browser viewport specifically, ScreenSizer gives you more detail than Windows settings because it shows CSS pixels, DPR, and viewport size separately.',
  },
  {
    id: 'faq-8',
    question: 'Does screen resolution affect website loading speed?',
    answer: 'Screen resolution affects the size of images that need to be served — higher DPR screens require 2x or 3x resolution images for sharp rendering. Using the HTML srcset attribute and CSS image-set(), you can serve appropriately sized images to each device. This directly impacts Core Web Vitals metrics like LCP (Largest Contentful Paint). ScreenSizer helps you identify your DPR to optimize accordingly.',
  },
];

export default function FAQSection() {
  const [open, setOpen] = useState<string | null>('faq-1');

  const toggle = (id: string) => setOpen(open === id ? null : id);

  const faqSchema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map((f) => ({
      '@type': 'Question',
      name: f.question,
      acceptedAnswer: { '@type': 'Answer', text: f.answer },
    })),
  };

  return (
    <section className="py-14 lg:py-20 bg-secondary/40" aria-labelledby="faq-heading">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-10">
        <div className="text-center mb-10">
          <h2 id="faq-heading" className="text-2xl sm:text-3xl font-700 text-foreground mb-3">
            Frequently Asked Questions
          </h2>
          <p className="text-muted-foreground text-sm sm:text-base max-w-xl mx-auto">
            Everything you need to know about screen size, resolution, and device detection.
          </p>
        </div>

        <div className="max-w-3xl mx-auto space-y-3">
          {faqs.map((faq) => (
            <div
              key={faq.id}
              className="bg-card border border-border rounded-xl overflow-hidden card-shadow"
            >
              <button
                onClick={() => toggle(faq.id)}
                aria-expanded={open === faq.id}
                className="w-full flex items-center justify-between p-5 text-left hover:bg-secondary/50 transition-colors duration-150"
              >
                <span className="text-sm sm:text-base font-600 text-foreground pr-4">{faq.question}</span>
                <ChevronDown
                  size={18}
                  className={`text-muted-foreground flex-shrink-0 transition-transform duration-200 ${open === faq.id ? 'rotate-180' : ''}`}
                />
              </button>
              {open === faq.id && (
                <div className="px-5 pb-5 animate-slide-up">
                  <p className="text-sm text-muted-foreground leading-relaxed border-t border-border pt-4">
                    {faq.answer}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}