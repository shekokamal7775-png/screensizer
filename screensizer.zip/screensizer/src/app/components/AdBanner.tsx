import React from 'react';

interface AdBannerProps {
  slot: string;
}

// BACKEND INTEGRATION: Replace this component with actual Google AdSense ad units
// AdSense publisher ID and slot IDs should be injected from environment variables
export default function AdBanner({ slot }: AdBannerProps) {
  return (
    <div
      className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-10 py-4"
      aria-label="Advertisement"
    >
      <div className="w-full bg-secondary/60 border border-dashed border-border rounded-xl flex items-center justify-center min-h-[90px] text-xs text-muted-foreground/50 select-none">
        {/* AdSense slot: {slot} — Insert google ad unit here */}
        Advertisement
      </div>
    </div>
  );
}