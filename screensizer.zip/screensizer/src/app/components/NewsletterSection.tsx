'use client';
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Mail, ArrowRight, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

interface NewsletterForm {
  email: string;
}

export default function NewsletterSection() {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<NewsletterForm>();

  const onSubmit = (data: NewsletterForm) => {
    setLoading(true);
    // BACKEND INTEGRATION: POST /api/newsletter with { email: data.email }
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
      toast.success('Subscribed! Check your inbox for confirmation.');
    }, 1000);
  };

  return (
    <section className="py-12 lg:py-16 bg-secondary/40" aria-labelledby="newsletter-heading">
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-10">
        <div className="max-w-2xl mx-auto text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/10 rounded-2xl mb-5">
            <Mail size={22} className="text-primary" />
          </div>
          <h2 id="newsletter-heading" className="text-xl sm:text-2xl font-700 text-foreground mb-3">
            Get Screen Size & Web Dev Tips
          </h2>
          <p className="text-muted-foreground text-sm mb-7">
            Subscribe to our newsletter for screen resolution guides, responsive design tips, and web performance articles — delivered twice a month. No spam, unsubscribe anytime.
          </p>

          {submitted ? (
            <div className="flex items-center justify-center gap-2 py-4">
              <CheckCircle size={20} className="text-success" />
              <span className="text-sm font-600 text-success">You are subscribed! Thank you.</span>
            </div>
          ) : (
            <form onSubmit={handleSubmit(onSubmit)} noValidate>
              <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
                <div className="flex-1">
                  <label htmlFor="newsletter-email" className="sr-only">Email address</label>
                  <input
                    id="newsletter-email"
                    type="email"
                    placeholder="you@example.com"
                    {...register('email', {
                      required: 'Email is required',
                      pattern: { value: /^\S+@\S+\.\S+$/, message: 'Enter a valid email address' },
                    })}
                    className="w-full px-4 py-2.5 bg-card border border-border rounded-xl text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 transition-all duration-150"
                  />
                  {errors.email && (
                    <p className="text-xs text-danger mt-1.5 text-left">{errors.email.message}</p>
                  )}
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex items-center justify-center gap-1.5 px-5 py-2.5 bg-primary text-primary-foreground text-sm font-600 rounded-xl hover:opacity-90 active:scale-95 transition-all duration-150 disabled:opacity-60 min-w-[120px]"
                >
                  {loading ? (
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>Subscribe <ArrowRight size={14} /></>
                  )}
                </button>
              </div>
            </form>
          )}
          <p className="text-xs text-muted-foreground mt-4">
            We respect your privacy. Read our{' '}
            <a href="/privacy-policy" className="text-primary hover:underline">Privacy Policy</a>.
          </p>
        </div>
      </div>
    </section>
  );
}