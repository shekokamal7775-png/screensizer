import React from 'react';
import { Monitor, Smartphone, Tablet, Tv } from 'lucide-react';

const devices = [
  {
    key: 'desktop',
    icon: <Monitor size={28} className="text-primary" />,
    name: 'Desktop',
    resolutions: ['1920 × 1080 (Full HD)', '2560 × 1440 (QHD)', '3840 × 2160 (4K UHD)', '1280 × 800 (Laptop)'],
    dpr: '1x – 2x',
    typical: 'Most common: 1920×1080',
    color: 'border-primary/20 bg-primary/5',
    badge: 'bg-primary/10 text-primary',
  },
  {
    key: 'mobile',
    icon: <Smartphone size={28} className="text-warning" />,
    name: 'Mobile',
    resolutions: ['390 × 844 (iPhone 14)', '412 × 915 (Pixel 7)', '360 × 780 (Samsung A)', '375 × 812 (iPhone X)'],
    dpr: '2x – 3x',
    typical: 'Most common: 390×844',
    color: 'border-warning/20 bg-warning/5',
    badge: 'bg-warning/15 text-warning',
  },
  {
    key: 'tablet',
    icon: <Tablet size={28} className="text-accent" />,
    name: 'Tablet',
    resolutions: ['820 × 1180 (iPad Air)', '768 × 1024 (iPad)', '800 × 1280 (Android)', '1024 × 1366 (iPad Pro)'],
    dpr: '1.5x – 2x',
    typical: 'Most common: 768×1024',
    color: 'border-accent/20 bg-accent/5',
    badge: 'bg-accent/10 text-accent',
  },
  {
    key: 'tv',
    icon: <Tv size={28} className="text-success" />,
    name: 'Smart TV / 4K',
    resolutions: ['3840 × 2160 (4K)', '1920 × 1080 (Full HD TV)', '7680 × 4320 (8K)', '2560 × 1440 (QHD TV)'],
    dpr: '1x',
    typical: 'Most common: 3840×2160',
    color: 'border-success/20 bg-success/5',
    badge: 'bg-success/10 text-success',
  },
];

export default function DeviceInfoCards() {
  return (
    <section className="py-12 lg:py-16 bg-secondary/40" aria-labelledby="device-cards-heading">
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-10">
        <div className="text-center mb-10">
          <h2 id="device-cards-heading" className="text-2xl sm:text-3xl font-700 text-foreground mb-3">
            Common Screen Resolutions by Device Type
          </h2>
          <p className="text-muted-foreground text-sm sm:text-base max-w-2xl mx-auto">
            Reference guide for developers and designers — the most widely used screen resolutions across all major device categories in 2025.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 2xl:grid-cols-4 gap-5">
          {devices?.map((d) => (
            <div
              key={`device-card-${d?.key}`}
              className={`bg-card border rounded-2xl p-6 card-shadow hover:card-shadow-hover hover:-translate-y-0.5 transition-all duration-200 ${d?.color}`}
            >
              <div className="flex items-center justify-between mb-5">
                <div className="p-2.5 bg-card rounded-xl border border-border card-shadow">
                  {d?.icon}
                </div>
                <span className={`text-xs font-600 px-2.5 py-1 rounded-full ${d?.badge}`}>
                  DPR: {d?.dpr}
                </span>
              </div>
              <h3 className="text-base font-700 text-foreground mb-1">{d?.name}</h3>
              <p className="text-xs text-muted-foreground mb-4">{d?.typical}</p>
              <ul className="space-y-2">
                {d?.resolutions?.map((res) => (
                  <li key={`res-${d?.key}-${res}`} className="flex items-center gap-2 text-sm text-secondary-foreground">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary/40 flex-shrink-0" />
                    <span className="font-mono text-xs">{res}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}