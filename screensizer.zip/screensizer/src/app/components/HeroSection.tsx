import React from 'react';
import LiveMetricDisplay from './LiveMetricDisplay';
import { Monitor, Zap, Shield, RefreshCw } from 'lucide-react';

export default function HeroSection() {
  return (
    <section
      id="tool"
      className="gradient-hero blob-bg pt-10 pb-16 lg:pt-16 lg:pb-24"
      aria-labelledby="hero-heading"
    >
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-10">
        {/* Heading */}
        <div className="text-center mb-10 lg:mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-primary/10 text-primary text-xs font-600 rounded-full mb-5 border border-primary/20">
            <Zap size={12} className="fill-primary" />
            Live Detection — Updates Automatically
          </div>
          <h1
            id="hero-heading"
            className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-800 text-foreground leading-tight tracking-tight text-balance mb-5"
          >
            What Is My{' '}
            <span className="text-primary relative">
              Screen Size
              <svg className="absolute -bottom-1 left-0 w-full" height="6" viewBox="0 0 200 6" fill="none" aria-hidden="true">
                <path d="M0 5 Q100 0 200 5" stroke="var(--primary)" strokeWidth="2.5" strokeLinecap="round" fill="none" opacity="0.4" />
              </svg>
            </span>
            ?
          </h1>
          <p className="text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Instantly detect your screen resolution, viewport dimensions, device pixel ratio, browser size, and more — no app download, no sign-up required.
          </p>

          {/* Trust badges */}
          <div className="flex flex-wrap items-center justify-center gap-4 mt-6">
            {[
              { icon: <Zap size={13} />, label: 'Instant Detection' },
              { icon: <RefreshCw size={13} />, label: 'Live Updates on Resize' },
              { icon: <Shield size={13} />, label: 'No Data Stored' },
              { icon: <Monitor size={13} />, label: 'All Devices Supported' },
            ]?.map((badge) => (
              <div
                key={`badge-${badge?.label}`}
                className="flex items-center gap-1.5 text-xs text-muted-foreground bg-card border border-border rounded-full px-3 py-1.5 card-shadow"
              >
                <span className="text-primary">{badge?.icon}</span>
                {badge?.label}
              </div>
            ))}
          </div>
        </div>

        {/* Live Display */}
        <LiveMetricDisplay />
      </div>
    </section>
  );
}